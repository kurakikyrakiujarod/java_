package cn.itcast.demo3;

//子类, 狗类
public class Dog extends Animal{
    String name = "Dog";
}
