/**
    这是我的第一个Java程序
 */
public class HelloWorld { // 这是在定义一个HelloWorld类, Java程序最小的单位是类.
    /**
        main方法是程序的主入口, 所有代码的执行都是从这里开始的.
    */
    public static void main(String[] args) {
        /*
            这里是main方法的主体,
            我们要实现的功能都要写在这里
        */
        //这是一个输出语句, 可以将结果打印到控制台中
        System.out.println("HelloWorld");
        //System.out.println("HelloWorld")
    }
}
