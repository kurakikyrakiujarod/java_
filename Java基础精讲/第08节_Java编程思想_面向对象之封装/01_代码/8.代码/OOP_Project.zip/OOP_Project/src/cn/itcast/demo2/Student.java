package cn.itcast.demo2;

/*
    定义一个学生类
 */
public class Student {
    //成员变量
    //姓名
    String name;  //成员变量
    //年龄
    int age;

    //成员方法
    //学习
    public void study() {
        //局部变量
        //String name = "小黑";
        System.out.println(name + "正在学习...");
    }
}
