package cn.itcast.demo1;
/*
    Child: 子类, 派生类
    Parent: 父类, 基类, 超类
 */
public class Child extends Parent {
}
