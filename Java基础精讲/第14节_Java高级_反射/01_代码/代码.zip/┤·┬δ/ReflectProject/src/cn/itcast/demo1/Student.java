package cn.itcast.demo1;

//学生类
public class Student {
}
