package cn.itcast.demo1;

//程序员类
public class Coder extends Employee{
   /* @Override
    public void show() {
        System.out.println("这个是垃圾文件");
    }*/
}
