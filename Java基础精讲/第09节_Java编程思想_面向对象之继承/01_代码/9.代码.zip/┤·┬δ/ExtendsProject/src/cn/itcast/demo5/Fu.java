package cn.itcast.demo5;

//父类
public class Fu {
    int num = 30;
}
