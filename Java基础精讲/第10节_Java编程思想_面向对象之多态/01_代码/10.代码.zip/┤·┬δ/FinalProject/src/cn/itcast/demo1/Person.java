package cn.itcast.demo1;

//人类
public class Person {
}
