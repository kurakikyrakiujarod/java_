package cn.itcast.demo2;

//子类, 狗类
public abstract class Dog extends Animal {
}
