package cn.itcast.demo4;

//子类, 猫类.
public class Cat extends Animal {
}
