package cn.itcasat.demo1;

//父类, 动物类(抽象类)
public abstract class Animal {
    //抽象方法(特点: 要求子类必须重写)
    public abstract void eat() ;
}
