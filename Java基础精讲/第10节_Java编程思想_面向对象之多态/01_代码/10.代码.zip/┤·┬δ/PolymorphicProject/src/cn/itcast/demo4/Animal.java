package cn.itcast.demo4;

//父类, 动物类
public class Animal {
    public void eat() {
        System.out.println("吃饭");
    }
}
