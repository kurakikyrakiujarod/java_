package cn.itcast;

public class HelloWorld {
}
