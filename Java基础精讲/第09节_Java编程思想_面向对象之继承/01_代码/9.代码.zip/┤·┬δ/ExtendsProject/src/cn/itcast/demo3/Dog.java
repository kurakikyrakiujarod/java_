package cn.itcast.demo3;

//定义一个狗类
public class Dog extends Animal{
    //定义看家的方法
    public void watch() {
        System.out.println("会看家");
    }
}
