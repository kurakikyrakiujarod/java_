package cn.itcast.demo3;

//定义猪类
public class Pig extends Animal{
    //打鼾
    public void snore() {
        System.out.println("会打鼾");
    }
}
