package cn.itcast.demo7;

//父类
public class Person {
    public Person(String name) {
        //System.out.println("Person类的 空参构造");
        System.out.println("Person类的带参构造 " + name);
    }
}
