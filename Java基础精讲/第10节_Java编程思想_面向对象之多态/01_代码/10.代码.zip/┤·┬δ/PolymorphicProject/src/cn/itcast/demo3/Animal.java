package cn.itcast.demo3;

//父类, 动物类
public class Animal {
    String name = "Animal";
}
